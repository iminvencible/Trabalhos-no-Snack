import React, { useState } from 'react';
import { StyleSheet, View, Text, TouchableOpacity } from 'react-native';
 
export default function App() {
  const [normalCount, setNormalCount] = useState(1);
  const [priorityCount, setPriorityCount] = useState(1);
  const [highPriorityCount, setHighPriorityCount] = useState(1);
  const [lastGeneratedTicket, setLastGeneratedTicket] = useState('');
 
  const generateTicket = (type) => {
    let ticketNumber = '';
 
    switch (type) {
      case 'normal':
        ticketNumber = `N0${normalCount}`;
        setNormalCount((prev) => prev + 1);
        break;
      case 'priority':
        ticketNumber = `P0${priorityCount}`;
        setPriorityCount((prev) => prev + 1);
        break;
      case 'highPriority':
        if (highPriorityCount < 10) {
          ticketNumber = `AP00${highPriorityCount}`;
        } else {
          ticketNumber = `AP0${highPriorityCount}`;
        }
        setHighPriorityCount((prev) => prev + 1);
        break;
      default:
        break;
    }
 
    setLastGeneratedTicket(ticketNumber);
  };
 
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Gerador de Senhas</Text>
 
      <TouchableOpacity
        style={[styles.button, styles.normalButton]}
        onPress={() => generateTicket('normal')}
      >
        <Text style={styles.buttonText}>Atendimento Normal</Text>
      </TouchableOpacity>
 
      <TouchableOpacity
        style={[styles.button, styles.priorityButton]}
        onPress={() => generateTicket('priority')}
      >
        <Text style={styles.buttonText}>Atendimento Prioritário</Text>
      </TouchableOpacity>
 
      <TouchableOpacity
        style={[styles.button, styles.highPriorityButton]}
        onPress={() => generateTicket('highPriority')}
      >
        <Text style={styles.buttonText}>Atendimento Alta Prioridade</Text>
      </TouchableOpacity>
 
      <View style={styles.ticketDisplay}>
        <Text style={styles.ticketText}>Última Senha Gerada:</Text>
        <Text style={styles.ticketNumber}>{lastGeneratedTicket}</Text>
      </View>
    </View>
  );
}
 
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f0f0f0',
    padding: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 40,
    color: '#333',
  },
  button: {
    width: '80%',
    padding: 20,
    borderRadius: 10,
    marginBottom: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  normalButton: {
    backgroundColor: '#4CAF50', // Verde
  },
  priorityButton: {
    backgroundColor: '#FFC107', // Amarelo
  },
  highPriorityButton: {
    backgroundColor: '#F44336', // Vermelho
  },
  buttonText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#fff',
  },
  ticketDisplay: {
    marginTop: 40,
    padding: 20,
    backgroundColor: '#fff',
    borderRadius: 10,
    width: '80%',
    alignItems: 'center',
  },
  ticketText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  ticketNumber: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#000',
    marginTop: 10,
  },
});
 